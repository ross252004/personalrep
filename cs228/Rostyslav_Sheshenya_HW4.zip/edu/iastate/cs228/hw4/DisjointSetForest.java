package edu.iastate.cs228.hw4;

/**
 * @author Rostyslav Sheshenya
 */
public class DisjointSetForest
{
public static void makeSet(MsgTree x)
{
x.p = x;
x.rank = 0;
}

public static void union(MsgTree x, MsgTree y)
{
link(findSet(x), findSet(y));
}

private static void link(MsgTree x, MsgTree y)
{
if (x.rank > y.rank) y.p = x;
else
{
x.p = y;
if (x.rank == y.rank) y.rank++;
}
}

public static MsgTree findSet(MsgTree x)
{
if (x != x.p) x.p = findSet(x.p);
return x.p;
}
}
