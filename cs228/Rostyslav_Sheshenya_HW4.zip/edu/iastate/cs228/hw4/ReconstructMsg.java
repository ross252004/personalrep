package edu.iastate.cs228.hw4;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.Scanner;
import java.util.LinkedList;
import java.util.Iterator;

/**
* @author Rostyslav Sheshenya
*/
public class ReconstructMsg
{
public static void main (String[] args)
{
Scanner msgScanner = new Scanner(System.in);
String fileName = null;
String encodingString = "";
FileInputStream msgStream = null;




System.out.println("Please enter file name to decode:");
fileName = msgScanner.next();
try
{
msgStream = new FileInputStream(fileName);
}
catch(FileNotFoundException e)
{
System.out.println(e.getMessage());
}
Scanner fileScanner = new Scanner(msgStream);
LinkedList<String> fileContents = new LinkedList<>();
LinkedList<Character> msgChars = new LinkedList<>();
while (fileScanner.hasNextLine())
{
fileContents.add(fileScanner.nextLine());
}

int h = 0;
for ( String a : fileContents )
{
if (a.charAt(0) != '0' && a.charAt(0) != '1')
{
for ( int i = 0; i < a.length(); i++ )
{
if (a.charAt(i) != ' ')
{
msgChars.add(a.charAt(i));
}
if (a.charAt(i) == ' ')
{
msgChars.add(' ');
}
}
h++;
}
msgChars.add('\n');
}


msgChars.remove(msgChars.size() - 1);


String code = "";
for ( int k = h; k < fileContents.size(); k++ )
{
code = code + fileContents.get(k);
code = code + "\n";
}


for ( Character a : msgChars )
{
encodingString = encodingString + a;
}


MsgTree msgTree2 = new MsgTree(encodingString);
System.out.println("character code");
System.out.println("----------------");
MsgTree.printCodes(msgTree2, encodingString);
System.out.println("MESSAGE:");
MsgTree.decode(msgTree2, code);
}
}
