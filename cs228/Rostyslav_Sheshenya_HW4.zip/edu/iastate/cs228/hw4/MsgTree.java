package edu.iastate.cs228.hw4;
import java.util.*;

/**
* @author Rostyslav Sheshenya
*/
public class MsgTree
{
public MsgTree p;
public int rank;
public Character payloadChar;
public MsgTree parent;
public MsgTree left;
public MsgTree right;
public static HashMap<MsgTree, String> color = new HashMap<MsgTree, String>();
public static HashMap<MsgTree, MsgTree> leastCommonAncestors = new HashMap<MsgTree, MsgTree>();
public static LinkedList<MsgTree> vMsgTreeNodes = new LinkedList<>();
public static ArrayList<String> finalState = new ArrayList<>();
public static HashMap<Character, String> charactersAndEncodings = new HashMap<>();


public static String treeData;
public static LinkedList<String> bitCodeData = null;
public MsgTree (String encodingString)
{
MsgTree tree = makeFromPrefix(encodingString);
this.payloadChar = tree.payloadChar;
setLeft(tree.left);
setRight(tree.right);
}

public MsgTree (Character payloadChar)
{
this.payloadChar = payloadChar;
}

public static void printCodes(MsgTree root, String code)
{
String treeData1 = code;
LinkedList<String> treeData2 = new LinkedList<>();

for ( int i = 0; i < treeData1.length(); i++ )
{
if (treeData1.charAt(i) != '^')
{
treeData2.add(String.valueOf(treeData1.charAt(i)));
}
}

String treeData3 = "";
for ( String a : treeData2 )
{
treeData3 = treeData3 + a;
}

String[] bitCodes = new String[treeData3.length()];

decodeCharacters(root);

for ( int i = 0; i < treeData3.length() - 1; i++ )
{
System.out.println(treeData3.charAt(i) + "\t\t  " + charactersAndEncodings.get(treeData3.charAt(i)));
}

setTreeData(treeData3);
setBitCodeData(new LinkedList<>());

for ( int i = 0; i < bitCodes.length - 1; i++ )
{
bitCodeData.add(charactersAndEncodings.get(treeData3.charAt(i)));
}

/* for ( int i = 0; i < bitCodeData.size(); i++ )
{
if (bitCodeData.get(i) == null)
{
bitCodeData.remove(i);
}
} */
}

public static void preOrderTraversal (MsgTree msgTreeName)
{
if (msgTreeName != null)
System.out.println(msgTreeName.payloadChar);
preOrderTraversal(msgTreeName.left);
preOrderTraversal(msgTreeName.right);
}

public static String preorderString(MsgTree msgTreeName)
{
StringBuilder sb = new StringBuilder();
if (msgTreeName != null)
{
makePreorderString(sb, msgTreeName);
}
return sb.toString();
}

private static void makePreorderString(StringBuilder sb, MsgTree msgTreeName)
{
if (msgTreeName != null)
{
sb.append(msgTreeName.payloadChar);
makePreorderString(sb, msgTreeName.left);
makePreorderString(sb, msgTreeName.right);
}
}

public static void decode (MsgTree codes, String msg)
{
String finalMsg = "";
Scanner msgScanner1 = new Scanner(msg);
while (msg.length() != 0)
{
int i = 0;
String name1 = "";
do
{
name1 = msgScanner1.findWithinHorizon(codes.bitCodeData.get(i), codes.bitCodeData.get(i).length());
++i;
} while (name1 == null && i < codes.bitCodeData.size());
if (treeData.charAt(i - 1) == '\n' || codes.treeData.charAt(i - 1) == ' ')
{
msg = msg.substring(1, msg.length());
finalMsg = finalMsg + codes.treeData.charAt(i - 1);
name1 = null;
}
else
{
if (codes.bitCodeData.get(i - 1).length() < msg.length())
{
msg = msg.substring(codes.bitCodeData.get(i - 1).length(), msg.length());
finalMsg = finalMsg + codes.treeData.charAt(i - 1);
}
else
{
msg = msg.substring(msg.length(), msg.length());
}
}
}
System.out.println(finalMsg);
}

// Decode characters helper
public static void decodeCharacters(MsgTree root)
{
tarjansLeastCommonAncestorAlgorithm(root);
Stack<String> reverseOrder = new Stack<>();

for (MsgTree v : vMsgTreeNodes)
{
if (v.payloadChar != '^')
{
reverseOrder.push(String.valueOf(getPath(leastCommonAncestors.get(v), root, v)));
}
}

ArrayList<String> correctOrder = new ArrayList<>();

while(!reverseOrder.isEmpty())
{
correctOrder.add(reverseOrder.pop());
}


for (String a : correctOrder)
{
StringBuilder a1 = new StringBuilder();
for ( int i = 0; i < a.length(); i++ )
{
if (a.charAt(i) != '[' && a.charAt(i) != ',' && a.charAt(i) != ' ' && a.charAt(i) != ']')
{
a1.append(a.charAt(i));
}
}
finalState.add(String.valueOf(a1));
}

ArrayList<MsgTree> vMsgTreeNodesCorrectOrder = new ArrayList<>();


for ( int i = vMsgTreeNodes.size() - 1; i >= 0; --i )
{
if (vMsgTreeNodes.get(i).payloadChar != '^')
{
vMsgTreeNodesCorrectOrder.add(vMsgTreeNodes.get(i));
}
}


for ( int i = 0; i < vMsgTreeNodesCorrectOrder.size(); i++ )
{
charactersAndEncodings.put(vMsgTreeNodesCorrectOrder.get(i).payloadChar, finalState.get(i));
}

}

public static void tarjansLeastCommonAncestorAlgorithm (MsgTree u)
{
DisjointSetForest.makeSet(u);
DisjointSetForest.findSet(u).setParent(u);

for (MsgTree v : u.adjacentTo(u))
{
tarjansLeastCommonAncestorAlgorithm(v);
DisjointSetForest.union(u, v);
DisjointSetForest.findSet(u).setParent(u);
}
color.put(u, "BLACK");

for (MsgTree v : u.adjacentTo(u))
{
if (color.get(v).equals("BLACK"))
{
/* System.out.println("The least common ancestor of " + u.payloadChar + " and " + v.payloadChar + " is " +
        DisjointSetForest.findSet(v).getParent()); */
leastCommonAncestors.put(v, DisjointSetForest.findSet(v).getParent());
vMsgTreeNodes.add(v);
}
}

}

public static Iterable<String> getPath(MsgTree root, MsgTree s, MsgTree t)
{
HashSet<MsgTree> seen = new HashSet<MsgTree>();
HashMap<MsgTree, MsgTree> pred = new HashMap<>();

visitDFS(root, s, seen, pred);

/* MsgTree cur = s;
ArrayList<String> path = new ArrayList<>();
Iterator iter1 = seen.iterator();
//iter1.next();
//might be necessary to use

while (!cur.isLeaf())
{
    if (iter1.next() == cur.left)
    {
        path.add("0");
    }
    if (iter1.next() == cur.right)
    {
        path.add("1");
    }
    cur = (MsgTree) iter1.next();
} */

if(!pred.containsKey(t))
   return null;

MsgTree cur = t;
Stack<String> revPath = new Stack<>();

while(cur != null)
{
if (pred.get(cur) != null && pred.get(cur).left == cur)
{
revPath.add("0");
}
if (pred.get(cur) != null && pred.get(cur).right == cur)
{
revPath.add("1");
}
cur = pred.get(cur);
}

ArrayList<String> path = new ArrayList<>();
while(!revPath.isEmpty())
{
path.add(revPath.pop());
}

return path;
}



public static void visitDFS (MsgTree root, MsgTree s, HashSet<MsgTree> seen, HashMap<MsgTree, MsgTree> pred)
{
seen.add(s);

for (MsgTree v : root.adjacentTo(s))
{
if (!seen.contains(v))
{
pred.put(v, s);
visitDFS(root, v, seen, pred);
}
}
}

public Iterable<MsgTree> adjacentTo(MsgTree v)
{
HashMap<MsgTree, HashSet<MsgTree>> map = new HashMap<>();
map.put(v, new HashSet<>());
if (v.right != null)
{
map.get(v).add(v.right);
}
if (v.left != null)
{
map.get(v).add(v.left);
}
return map.get(v);
}

public boolean isLeaf()
{
return left == null && right == null;
}

public MsgTree makeFromPrefix(String encodingString)
{
    Deque<MsgTree> s = new LinkedList<MsgTree>();
    for (int i = encodingString.length() - 1; i >= 0; --i)
    {
        Character c = encodingString.charAt(i);
        if ('^' == c)
        {
            MsgTree temp = new MsgTree('^');
            temp.setLeft(s.pop());
            temp.getLeft().setParent(temp);
            temp.setRight(s.pop());
            temp.getRight().setParent(temp);
            s.push(temp);
        }
        else
        {
            s.push(new MsgTree(c));
        }
    }
    return s.pop();
}

public void setLeft (MsgTree msgTreeNode)
{
this.left = msgTreeNode;
}

public MsgTree getLeft()
{
return this.left;
}

public void setRight (MsgTree msgTreeNode)
{
this.right = msgTreeNode;
}

public MsgTree getRight ()
{
return this.right;
}

public void setParent (MsgTree node)
{
this.parent = node;
}

public MsgTree getParent()
{
return this.parent;
}

public static void setBitCodeData(LinkedList<String> name)
{
bitCodeData = name;
}

public static void setTreeData(String name)
{
treeData = name;
}
}

