package edu.iastate.cs228.hw2;

import java.io.FileNotFoundException;
import java.lang.NumberFormatException; 
import java.lang.IllegalArgumentException; 
import java.util.InputMismatchException;

/**
 *  
 * @author Ross Sheshenya
 *
 */

/**
 * 
 * This class implements the mergesort algorithm.   
 *
 */

public class MergeSorter extends AbstractSorter
{
	// Other private instance variables if needed
	
	/** 
	 * Constructor takes an array of points.  It invokes the superclass constructor, and also 
	 * set the instance variables algorithm in the superclass.
	 *  
	 * @param pts   input array of integers
	 */
	public MergeSorter(Point[] pts) 
	{
		// TODO
		super(pts);
		super.algorithm = "mergesort";
	}


	/**
	 * Perform mergesort on the array points[] of the parent class AbstractSorter. 
	 * 
	 */
	@Override 
	public void sort()
	{
		// TODO
		long startTime = System.nanoTime();

		int n = points.length;

		mergeSortRec(points, n);

		long totalRunningTime = System.nanoTime() - startTime;
		tempScanTime = totalRunningTime;
	}

	
	/**
	 * This is a recursive method that carries out mergesort on an array pts[] of points. One 
	 * way is to make copies of the two halves of pts[], recursively call mergeSort on them, 
	 * and merge the two sorted subarrays into pts[].   
	 * 
	 * @param pts	point array 
	 */
	private void mergeSortRec(Point[] pts, int n)
	{
		if (n < 2)
		{
			return;
		}
		int mid = n / 2;
		Point[] l = new Point[mid];
		Point[] r = new Point[n - mid];

		for (int i = 0; i < mid; i++)
		{
			l[i] = (Point) pts[i].clone();
		}
		for (int i = mid; i < n; i++)
		{
			r[i - mid] = (Point) pts[i].clone();
		}
		mergeSortRec(l, mid);
		mergeSortRec(r, n - mid);

		merge(pts, l, r, mid, n - mid);
	}

	private void merge(Point[] pts, Point[] l, Point[] r, int left, int right)
	{

		int i = 0, j = 0, k = 0;
		while (i < left && j < right)
		{
			if (pointComparator.compare(l[i], r[j]) < 0 || pointComparator.compare(l[i], r[j]) == 0)
			{
				pts[k++] = (Point) l[i++].clone();
			} else
			{
				pts[k++] = (Point) r[j++].clone();
			}
		}
		while (i < left)
		{
			pts[k++] = (Point) l[i++].clone();
		}
		while (j < right)
		{
			pts[k++] = (Point) r[j++].clone();
		}
	}

	
	// Other private methods if needed ...

}
