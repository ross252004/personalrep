 package edu.iastate.cs228.hw2;

/**
 *  
 * @author Ross Sheshenya
 *
 */

public class Point implements Comparable<Point>, Cloneable
{
	private int x; 
	private int y;
	
	public static boolean xORy;  // compare x coordinates if xORy == true and y coordinates otherwise 
	                             // To set its value, use Point.xORy = true or false. 
	
	public Point()  // default constructor
	{
	x = 0;
	y = 0;
		// x and y get default value 0
	}
	
	public Point(int x, int y)
	{
		this.x = x;  
		this.y = y;   
	}
	
	public Point(Point p)
	{ // copy constructor
		x = p.getX();
		y = p.getY();
	}

	public int getX()   
	{
		return x;
	}
	
	public int getY()
	{
		return y;
	}
	
	/** 
	 * Set the value of the static instance variable xORy. 
	 * @param xORy
	 */
	public static void setXorY(boolean xORy)
	{
		// TODO
		Point.xORy = xORy;
	}
	
	
	@Override
	public boolean equals(Object obj)
	{
		if (obj == null || obj.getClass() != this.getClass())
		{
			return false;
		}
    
		Point other = (Point) obj;
		return x == other.x && y == other.y;   
	}

	/**
	 * Compare this point with a second point q depending on the value of the static variable xORy 
	 * @param 	q 
	 * @return  -1  if (xORy == true && (this.x < q.x || (this.x == q.x && this.y < q.y))) 
	 *                || (xORy == false && (this.y < q.y || (this.y == q.y && this.x < q.x)))
	 * 		    0   if this.x == q.x && this.y == q.y)  
	 * 			1	otherwise 
	 */
	public int compareTo(Point q)
	{
		if (xORy == true)
		{
		return this.getX() - q.getX();
		}
		if (xORy == false)
		{
		return this.getY() - q.getY();
		}
		return 0;
		// TODO; 
	}
	
	
	/**
	 * Output a point in the standard form (x, y). 
	 */
	@Override
    public String toString() 
	{
		// TODO
		String pointValues;
		pointValues = "(" + this.getX() + ", " + this.getY() + ")";
		return pointValues;
	}

	@Override
	public Object clone()
	{
	Point copy = null;
	try
	{
	copy = (Point) super.clone();
	}
	catch (CloneNotSupportedException e)
	{
	System.out.println("The following error has occurred: " + e);

	return null;
	}
	return copy;
	}
}
