package edu.iastate.cs228.hw2;

/**
 *  
 * @author Ross Sheshenya
 *
 */

/**
 * 
 * This class executes four sorting algorithms: selection sort, insertion sort, mergesort, and
 * quicksort, over randomly generated integers as well integers from a file input. It compares the 
 * execution times of these algorithms on the same input. 
 *
 */

import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.LinkedList;
import java.util.Scanner;
import java.util.Random;


public class CompareSorters 
{
	/**
	 * Repeatedly take integer sequences either randomly generated or read from files. 
	 * Use them as coordinates to construct points.  Scan these points with respect to their 
	 * median coordinate point four times, each time using a different sorting algorithm.  
	 * 
	 * @param args
	 **/
	public static void main(String[] args) throws FileNotFoundException
	{		
		// TODO 
		// 
		// Conducts multiple rounds of comparison of four sorting algorithms.  Within each round, 
		// set up scanning as follows: 
		// 
		//    a) If asked to scan random points, calls generateRandomPoints() to initialize an array 
		//       of random points. 
		// 
		//    b) Reassigns to the array scanners[] (declared below) the references to four new 
		//       PointScanner objects, which are created using four different values  
		//       of the Algorithm type:  SelectionSort, InsertionSort, MergeSort and QuickSort. 
		// 
		//
		PointScanner[] scanners = new PointScanner[4];
		Scanner defaultScanner = new Scanner(System.in);
		Random randomGenerator = new Random();
		Point[] randomPointsGenerated;
		int randomPointsNumber;
		int keyChoice;
		String filePath;
		String outputFileName = "MCPdata.txt";


		try
		{
		Files.deleteIfExists(Path.of(outputFileName));
		Files.createFile(Path.of(outputFileName));
		}
		catch (IOException e)
		{
		System.out.println(e.getMessage());
		}

		System.out.println("Key in your choice: 1 - random integers, 2 - input from a file, 3 - proceed to exit");
		System.out.println("Trial #");
		do
		{
			keyChoice = defaultScanner.nextInt();
			switch (keyChoice)
			{
				case 1:
					System.out.println("Enter the number of random points:");
					randomPointsNumber = defaultScanner.nextInt();
					randomPointsGenerated = generateRandomPoints(randomPointsNumber, randomGenerator);

					scanners[0] = new PointScanner(randomPointsGenerated, Algorithm.SelectionSort);
					scanners[1] = new PointScanner(randomPointsGenerated, Algorithm.InsertionSort);
					scanners[2] = new PointScanner(randomPointsGenerated, Algorithm.MergeSort);
					scanners[3] = new PointScanner(randomPointsGenerated, Algorithm.QuickSort);

					PointScanner.mcpData = new LinkedList<>();
					PointScanner.mcpData.clear();

					for ( PointScanner a : scanners )
					{
					try
					{
					a.scan();
					}
					catch (NullPointerException e)
					{
					System.out.println(e.getMessage());
					}

					}

					System.out.println("algorithm         size    time (ns)");
					System.out.println("-----------------------------------");
					for ( PointScanner a : scanners )
					{
						System.out.println(a.stats());
					}
					System.out.println("-----------------------------------");
					System.out.println();
					System.out.println("Trial #");
					break;
				case 2:
					System.out.println("File path:");
					filePath = defaultScanner.next();

					scanners[0] = new PointScanner(filePath, Algorithm.SelectionSort);
					scanners[1] = new PointScanner(filePath, Algorithm.InsertionSort);
					scanners[2] = new PointScanner(filePath, Algorithm.MergeSort);
					scanners[3] = new PointScanner(filePath, Algorithm.QuickSort);

					PointScanner.mcpData = new LinkedList<>();
					PointScanner.mcpData.clear();

					for ( PointScanner a : scanners )
					{
						a.scan();
					}

					System.out.println("algorithm         size    time (ns)");
					System.out.println("-----------------------------------");
					for ( PointScanner a : scanners )
					{
						System.out.println(a.stats());
					}
					System.out.println("-----------------------------------");
					System.out.println();
					System.out.println("Trial #");
					break;
			}
		} while (keyChoice != 3);






		// For each input of points, do the following. 
		// 
		//     a) Initialize the array scanners[].  
		//
		//     b) Iterate through the array scanners[], and have every scanner call the scan() 
		//        method in the PointScanner class.  
		//
		//     c) After all four scans are done for the input, print out the statistics table from
		//		  section 2.
		//
		// A sample scenario is given in Section 2 of the project description. 
		
	}
	
	
	/**
	 * This method generates a given number of random points.
	 * The coordinates of these points are pseudo-random numbers within the range 
	 * [-50,50] × [-50,50]. Please refer to Section 3 on how such points can be generated.
	 * 
	 * Ought to be private. Made public for testing. 
	 * 
	 * @param numPts  	number of points
	 * @param rand      Random object to allow seeding of the random number generator
	 * @throws IllegalArgumentException if numPts < 1
	 */
	public static Point[] generateRandomPoints(int numPts, Random rand) throws IllegalArgumentException
	{
		Point[] randomPoints;
		int randomX;
		int randomY;

		randomPoints = new Point[numPts];

		for ( int i = 0; i < randomPoints.length; i++ )
		{
		randomPoints[i] = new Point();
		randomX = rand.nextInt(101) - 50;
		randomY = rand.nextInt(101) - 50;
		randomPoints[i] = new Point(randomX, randomY);
		}

		return randomPoints;
	}
}
