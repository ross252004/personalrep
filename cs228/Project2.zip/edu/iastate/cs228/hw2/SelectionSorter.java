package edu.iastate.cs228.hw2;

import java.io.FileNotFoundException;
import java.lang.NumberFormatException; 
import java.lang.IllegalArgumentException; 
import java.util.InputMismatchException;


/**
 *  
 * @author Ross Sheshenya
 *
 */

/**
 * 
 * This class implements selection sort.   
 *
 */

public class SelectionSorter extends AbstractSorter
{
	// Other private instance variables if you need ... 
	
	/**
	 * Constructor takes an array of points.  It invokes the superclass constructor, and also 
	 * set the instance variables algorithm in the superclass.
	 *  
	 * @param pts  
	 */
	public SelectionSorter(Point[] pts)  
	{
		// TODO
		super(pts);
		super.algorithm = "selection sort";
	}	

	
	/** 
	 * Apply selection sort on the array points[] of the parent class AbstractSorter.  
	 * 
	 */
	@Override 
	public void sort()
	{
		// TODO
		long startTime = System.nanoTime();

		int n = points.length;
		int min_idx = 0;
		Point temp;

		for (int i = 0; i < n - 1; i++)
		{

			// Find the minimum element in
			// unsorted array
			min_idx = i;
			for (int j = i + 1; j < n; j++) {
				if (pointComparator.compare(points[j], points[min_idx]) < 0)
					min_idx = j;
			}

			// Swap the found minimum element with the first element
			temp = (Point) points[min_idx].clone();
			points[min_idx] = (Point) points[i].clone();
			points[i] = (Point) temp.clone();
		}

		long totalRunningTime = System.nanoTime() - startTime;
		tempScanTime = totalRunningTime;
	}	
}
