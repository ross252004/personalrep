package edu.iastate.cs228.hw3;

import java.util.AbstractSequentialList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Iterator;
import java.util.ListIterator;
import java.util.NoSuchElementException;

/**
 * Implementation of the list interface based on linked nodes
 * that store multiple items per node.  Rules for adding and removing
 * elements ensure that each node (except possibly the last one)
 * is at least half full.
 */
public class StoutList<E extends Comparable<? super E>> extends AbstractSequentialList<E>
{
    /**
     * Default number of elements that may be stored in each node.
     */
    private static final int DEFAULT_NODESIZE = 4;

    /**
     * Number of elements that can be stored in each node.
     */
    private final int nodeSize;

    /**
     * Dummy node for head.  It should be private but set to public here only
     * for grading purpose.  In practice, you should always make the head of a
     * linked list a private instance variable.
     */
    public Node head;

    /**
     * Dummy node for tail.
     */
    private Node tail;

    private Node temporary;

    private NodeDetails tempDetails;

    /**
     * Number of elements in the list.
     */
    private int size;


    /**
     * Constructs an empty list with the default node size.
     */
    public StoutList()
    {
        this(DEFAULT_NODESIZE);
    }

    /**
     * Constructs an empty list with the given node size.
     * @param nodeSize number of elements that may be stored in each node, must be
     *   an even number
     */
    public StoutList(int nodeSize)
    {
        if (nodeSize <= 0 || nodeSize % 2 != 0) throw new IllegalArgumentException();

        // dummy nodes
        head = new Node();
        tail = new Node();
        head.next = tail;
        tail.previous = head;
        this.nodeSize = nodeSize;
    }

    /**
     * Constructor for grading only.  Fully implemented.
     * @param head
     * @param tail
     * @param nodeSize
     * @param size
     */
    public StoutList(Node head, Node tail, int nodeSize, int size)
    {
        this.head = head;
        this.tail = tail;
        this.nodeSize = nodeSize;
        this.size = size;
    }

    @Override
    public int size()
    {
        // TODO Auto-generated method stub
        return this.size;
    }


    @Override
    public boolean add(E item)
    {
        // TODO Auto-generated method stub
    if (tail.previous == head)
    {
    temporary = new Node();
    temporary.addItem(item);
    temporary.details = new NodeDetails(temporary, temporary.count);
    link(tail.previous, temporary);
    size++;
    return true;
    }
    if(tail.previous.data[nodeSize - 1] != null)
    {
    temporary = new Node();
    temporary.addItem(item);
    temporary.details = new NodeDetails(temporary, temporary.count);
    link(tail.previous, temporary);
    size++;
    return true;
    }
    else
    {
    temporary.addItem(item);
    temporary.details.setOffset(temporary.count);
    size++;
    return true;
    }
    }

    @Override
    public void add(int pos, E item)
    {
    // TODO Auto-generated method stub
    Node nodeToAdd = find(pos);
    int offset = posToOffset(nodeToAdd, pos);
    if(offset == 0)
    {
    if (nodeToAdd.previous == head)
    {
    if (nodeToAdd == tail)
    {
    temporary = new Node();
    temporary.addItem(0, item);
    temporary.details = new NodeDetails(temporary, temporary.count);
    link(nodeToAdd.previous, temporary);
    size++;
    }
    if (nodeToAdd != tail && nodeToAdd.details.getOffset() == nodeSize)
    {
    split(nodeToAdd, offset, item);
    }
    }
    if (nodeToAdd.previous != head)
    {
    if (nodeToAdd.previous.details.getOffset() != nodeSize)
    {
    temporary = (Node) nodeToAdd.previous.clone();
    temporary.addItem(item);
    unlink(nodeToAdd.previous);
    link(nodeToAdd.previous, temporary);
    nodeToAdd.previous.details.setNode(temporary);
    nodeToAdd.previous.details.setOffset(temporary.count);
    size++;
    }
    if (nodeToAdd == tail && nodeToAdd.previous.details.getOffset() == nodeSize)
    {
    temporary = new Node();
    temporary.addItem(0, item);
    temporary.details = new NodeDetails(temporary, temporary.count);
    link(nodeToAdd.previous, temporary);
    size++;
    }
    }
    }
    if (offset != 0)
    {
    if (nodeToAdd.details.getOffset() != nodeSize)
    {
    temporary = (Node) nodeToAdd.clone();
    temporary.addItem(item);
    link(nodeToAdd.previous, temporary);
    unlink(nodeToAdd);
    nodeToAdd.details.setNode(temporary);
    nodeToAdd.details.setOffset(temporary.count);
    }
    else
    {
    split(nodeToAdd, offset, item);
    }
    }
    }

    @Override
    public E remove(int pos)
    {
    // TODO Auto-generated method stub
    temporary.removeItem(pos);
    temporary.details.setOffset(temporary.count);
    size--;
    if (temporary.data[0] == null)
    {
    unlink(temporary);
    return null;
    }
    else
    return null;
    }

    private void link(Node nodeInTheList, Node nodeToConnect)
    {
    nodeToConnect.previous = nodeInTheList;
    nodeToConnect.next = nodeInTheList.next;
    nodeInTheList.next.previous = nodeToConnect;
    nodeInTheList.next = nodeToConnect;
    }

    private void unlink(Node nodeInTheList)
    {
    nodeInTheList.previous.next = nodeInTheList.next;
    nodeInTheList.next.previous = nodeInTheList.previous;
    }

    private void split(Node node, int offset, E item)
    {
    int m2 = nodeSize / 2;
    int k = m2;
    temporary = new Node();
    for ( int i = 0; i < m2; i++ )
    {
    temporary.data[i] = node.data[k];
    node.removeItem(k);
    size--;
    }
    if ( offset <= (nodeSize / 2) )
    {
    temporary.details = new NodeDetails(temporary, temporary.count);
    link(node, temporary);
    temporary = (Node) node.clone();
    temporary.addItem(offset, item);
    node.details.setNode(temporary);
    node.details.setOffset(temporary.count);
    link(node.previous, temporary);
    unlink(node);
    size++;
    }
    else
    {
    int newOffset = offset - m2;
    if (temporary.data[newOffset] != null)
    {
    shift(temporary, newOffset);
    temporary.addItem(newOffset, item);
    temporary.details = new NodeDetails(temporary, temporary.count);
    link(node, temporary);
    size++;
    }
    if (temporary.data[newOffset] == null)
    {
    temporary.addItem(newOffset, item);
    temporary.details = new NodeDetails(temporary, temporary.count);
    link(node, temporary);
    size++;
    }
    }
    }

    private void shift (Node node, int offset)
    {
    for ( int i = node.details.getOffset() - 1; i >= offset; i-- )
    {
    if (i + 1 != nodeSize)
    {
    node.data[i+1] = node.data[i];
    node.removeItem(i);
    }
    }
    }

    /**
     * Sort all elements in the stout list in the NON-DECREASING order. You may do the following.
     * Traverse the list and copy its elements into an array, deleting every visited node along
     * the way.  Then, sort the array by calling the insertionSort() method.  (Note that sorting
     * efficiency is not a concern for this project.)  Finally, copy all elements from the array
     * back to the stout list, creating new nodes for storage. After sorting, all nodes but
     * (possibly) the last one must be full of elements.
     *
     * Comparator<E> must have been implemented for calling insertionSort().
     */
    public void sort()
    {
        // TODO
    }

    /**
     * Sort all elements in the stout list in the NON-INCREASING order. Call the bubbleSort()
     * method.  After sorting, all but (possibly) the last nodes must be filled with elements.
     *
     * Comparable<? super E> must be implemented for calling bubbleSort().
     */
    public void sortReverse()
    {
        // TODO
    }

    @Override
    public Iterator<E> iterator()
    {
        // TODO Auto-generated method stub
        return new StoutListIterator();
    }

    @Override
    public ListIterator<E> listIterator()
    {
        // TODO Auto-generated method stub
        return new StoutListIterator();
    }

    @Override
    public ListIterator<E> listIterator(int index)
    {
        // TODO Auto-generated method stub
        return new StoutListIterator(index);
    }

    public Node find(int pos)
    {
        Node intermediateNode = head.next;
        int i = 0;
        int b = intermediateNode.details.getOffset();
        while(i < size() && b < pos)
        {
            intermediateNode = intermediateNode.next;
            b+= intermediateNode.details.getOffset();
            ++i;
        }
        return intermediateNode.details.node1;
    }

    public int posToOffset (Node node,int pos)
    {
    int offset = pos;
    while (node.previous != head)
    {
    offset = offset - node.previous.details.getOffset();
    node = node.previous;
    }
    return offset;
    }

//    public NodeDetails add(Node n, int offset, E item)
//    {
//    if (n.previous == head)
//    {
//    n.previous = new Node();
//    temporary.details = new NodeDetails(temporary, temporary.count);
//    temporary.addItem(item);
//    link(tail.previous, temporary);
//    size++;
//    }
//    }



    public int getCurrentOffset(Node intermediateNode, int index)
    {
        int offset = 0;
        while(intermediateNode.previous != head)
        {
            offset += intermediateNode.previous.details.getOffset();
            intermediateNode = intermediateNode.previous;
        }
        offset = offset + index;
        return offset;
    }

    /**
     * Returns a string representation of this list showing
     * the internal structure of the nodes.
     */
    public String toStringInternal()
    {
        return toStringInternal(null);
    }

    /**
     * Returns a string representation of this list showing the internal
     * structure of the nodes and the position of the iterator.
     *
     * @param iter
     *            an iterator for this list
     */
    public String toStringInternal(ListIterator<E> iter)
    {
        int count = 0;
        int position = -1;
        if (iter != null) {
            position = iter.nextIndex();
        }

        StringBuilder sb = new StringBuilder();
        sb.append('[');
        Node current = head.next;
        while (current != tail) {
            sb.append('(');
            E data = current.data[0];
            if (data == null) {
                sb.append("-");
            } else {
                if (position == count) {
                    sb.append("| ");
                    position = -1;
                }
                sb.append(data.toString());
                ++count;
            }

            for (int i = 1; i < nodeSize; ++i) {
                sb.append(", ");
                data = current.data[i];
                if (data == null) {
                    sb.append("-");
                } else {
                    if (position == count) {
                        sb.append("| ");
                        position = -1;
                    }
                    sb.append(data.toString());
                    ++count;

                    // iterator at end
                    if (position == size && count == size) {
                        sb.append(" |");
                        position = -1;
                    }
                }
            }
            sb.append(')');
            current = current.next;
            if (current != tail)
                sb.append(", ");
        }
        sb.append("]");
        return sb.toString();
    }


    /**
     * Node type for this list.  Each node holds a maximum
     * of nodeSize elements in an array.  Empty slots
     * are null.
     */
    private class Node implements Cloneable
    {
        /**
         * Array of actual data elements.
         */
        // Unchecked warning unavoidable.
        public E[] data = (E[]) new Comparable[nodeSize];

        /**
         * Link to next node.
         */
        public Node next;

        /**
         * Link to previous node;
         */
        public Node previous;

        public NodeDetails details;

        /**
         * Index of the next available offset in this node, also
         * equal to the number of elements in this node.
         */
        public int count;

        /**
         * Adds an item to this node at the first available offset.
         * Precondition: count < nodeSize
         * @param item element to be added
         */
        void addItem(E item)
        {
            if (count >= nodeSize)
            {
                return;
            }
            data[count++] = item;
            //useful for debugging
            //      System.out.println("Added " + item.toString() + " at index " + count + " to node "  + Arrays.toString(data));
        }

        /**
         * Adds an item to this node at the indicated offset, shifting
         * elements to the right as necessary.
         *
         * Precondition: count < nodeSize
         * @param offset array index at which to put the new element
         * @param item element to be added
         */
        void addItem(int offset, E item)
        {
            if (count >= nodeSize)
            {
                return;
            }
            for ( int i = count - 1; i >= offset; --i )
            {
                data[i + 1] = data[i];
            }
            ++count;
            data[offset] = item;
            ++count;
            data[offset] = item;
            //useful for debugging
//      System.out.println("Added " + item.toString() + " at index " + offset + " to node: "  + Arrays.toString(data));
        }

        /**
         * Deletes an element from this node at the indicated offset,
         * shifting elements left as necessary.
         * Precondition: 0 <= offset < count
         * @param offset
         */
        void removeItem(int offset)
        {
            E item = data[offset];
            for (int i = offset + 1; i < nodeSize; ++i)
            {
                data[i - 1] = data[i];
            }
            data[count - 1] = null;
            count--;
        }

        protected void swap(int i, int j)
        {
            // TODO
            E temp = data[i];
            data[i] = data[j];
            data[j] = temp;
        }

        @Override
        public Node clone()
        {
            try
            {
                Node copy = (Node) super.clone();

                copy.data = (E[]) new Comparable[nodeSize];
                for ( int i = 0; i < nodeSize; i++ )
                {
                    copy.data[i] = data[i];
                }
                return copy;
            }
            catch (CloneNotSupportedException e)
            {
                return null;
            }
        }
    }

    private class NodeDetails implements Cloneable
    {
    private Node node1;
    private int offset;


    public NodeDetails(Node intermediateNode, int offset)
    {
    this.node1 = intermediateNode;
    this.offset = offset;
    }

    public void setNode(Node intermediateNode)
{
node1 = intermediateNode;
}

    public void setOffset(int offset)
    {
    this.offset = offset;
    }

    public int getOffset()
    {
    return this.offset;
    }
    public Node getNode()
    {
    return this.node1;
    }
    }
    private class StoutListIterator implements ListIterator<E>
    {
        // constants you possibly use ...
        private static final int BEHIND = -1;
        private static final int AHEAD = 1;
        private static final int NONE = 0;
        // instance variables ...

        private Node cursor;
        private int index;
        private int direction;

        /**
         * Default constructor
         */
        public StoutListIterator()
        {
            // TODO
            this(0);
        }

        /**
         * Constructor finds node at a given position.
         * @param pos
         */
        public StoutListIterator(int pos)
        {
            // TODO
        if (pos < 0 || pos > size)
        {
        throw new IndexOutOfBoundsException();
        }

        cursor = find(pos);
        if (pos > nodeSize)
        {
        index = pos - nodeSize;
        }
        else
        {
        index = pos;
        }
        direction = NONE;
        }


        @Override
        public boolean hasNext()
        {
            // TODO
        return getCurrentOffset(cursor, nextIndex()) < size;
        }

        @Override
        public boolean hasPrevious()
        {
        return getCurrentOffset(cursor, index) > 0;
        }

        @Override
        public int nextIndex()
        {
        return index;
        }

        @Override
        public int previousIndex()
        {
        return index - 1;
        }


        @Override
        public E next()
        {
            // TODO
        if(!hasNext())
        throw new NoSuchElementException();
        if(index < nodeSize)
        {
        E nextItem = cursor.data[index];
        index++;
        direction = BEHIND;
        return nextItem;
        }
        else
        {
        index = 0;
        cursor = cursor.next;
        E nextItem = cursor.data[index];
        index++;
        direction = BEHIND;
        return nextItem;
        }
        }

        @Override
        public E previous()
        {
        // TODO
        if(!hasPrevious())
        throw new NoSuchElementException();

        if (index > 0)
        {
        index--;
        direction = AHEAD;
        return cursor.data[index];
        }
        else
        {
        index = nodeSize - 1;
        cursor = cursor.previous;
        direction = AHEAD;
        return cursor.data[index];
        }
        }

        @Override
        public void remove()
        {
            // TODO
        }

        @Override
        public void set(E item)
        {
        if (direction == NONE)
        {
        throw new IllegalStateException();
        }
        if(direction == AHEAD)
        {
        cursor.data[index] = item;
        }
        if (direction == BEHIND && index == 0)
        {
        cursor = cursor.previous;
        cursor.data[nodeSize - 1] = item;
        }
        if (direction == BEHIND && index != 0)
        {
        cursor.data[index-1] = item;
        }
        }

        @Override
        public void add(E item)
        {

        }

        // Other methods you may want to add or override that could possibly facilitate
        // other operations, for instance, addition, access to the previous element, etc.
        //
        // ...
        //
    }


    /**
     * Sort an array arr[] using the insertion sort algorithm in the NON-DECREASING order.
     * @param arr   array storing elements from the list
     * @param comp  comparator used in sorting
     */
    private void insertionSort(E[] arr, Comparator<? super E> comp)
    {
        // TODO
    }

    /**
     * Sort arr[] using the bubble sort algorithm in the NON-INCREASING order. For a
     * description of bubble sort please refer to Section 6.1 in the project description.
     * You must use the compareTo() method from an implementation of the Comparable
     * interface by the class E or ? super E.
     * @param arr  array holding elements from the list
     */
    private void bubbleSort(E[] arr)
    {
        // TODO
    }


}