package edu.iastate.cs228.hw3;

import java.util.ListIterator;

public class StoutList_MAIN
{
public static void main(String[] args)
{
StoutList<String> newList = new StoutList<>();
String randomString = new String("Testing in progress");
newList.add(randomString);
newList.add("second item");
newList.add("third item");
newList.add("Testing in progress");
newList.add("A");
newList.add(5, "B");
System.out.println(newList.toStringInternal());
newList.add(0, "B");
System.out.println(newList.toStringInternal());
newList.add(1, "B");
System.out.println(newList.toStringInternal());
System.out.println(newList.toStringInternal());


}
}
